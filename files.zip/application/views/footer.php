    <script src="<?=base_url('assets/bootstrap/js/jquery.min.js')?>"></script>
    <script src="<?=base_url('assets/bootstrap/js/bootstrap.min.js')?>"></script>
    <script src="<?=base_url('assets/styles/js/main.js')?>"></script>
    <script src="<?=base_url('assets/datatables/datatables.min.js')?>"></script>
  </body>
</html>